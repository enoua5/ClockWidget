# ClockWidget
A clock widget for a group project in our java class.
